package com.Corhuila.Corte2JesusGonzalez;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Corte2JesusGonzalezApplicationTests {

	@Test
	void contextLoads() {
	}

}
