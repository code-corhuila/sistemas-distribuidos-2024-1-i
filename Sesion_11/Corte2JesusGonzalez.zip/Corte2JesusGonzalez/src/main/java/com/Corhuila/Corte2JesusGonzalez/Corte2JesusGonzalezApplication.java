package com.Corhuila.Corte2JesusGonzalez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Corte2JesusGonzalezApplication {

	public static void main(String[] args) {
		SpringApplication.run(Corte2JesusGonzalezApplication.class, args);
	}

}
