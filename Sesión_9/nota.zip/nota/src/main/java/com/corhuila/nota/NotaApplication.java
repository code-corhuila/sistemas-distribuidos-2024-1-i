package com.corhuila.nota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotaApplication.class, args);
	}

}
