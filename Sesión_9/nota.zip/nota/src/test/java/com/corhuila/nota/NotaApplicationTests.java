package com.corhuila.nota;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotaApplicationTests {

	@Test
	void contextLoads() {
	}

}
